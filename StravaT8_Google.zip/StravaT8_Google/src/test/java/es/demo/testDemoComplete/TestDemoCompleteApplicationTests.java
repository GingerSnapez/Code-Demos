package es.demo.testDemoComplete;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestDemoCompleteApplicationTests {

	@Test
	void contextLoads() {
	}

}
