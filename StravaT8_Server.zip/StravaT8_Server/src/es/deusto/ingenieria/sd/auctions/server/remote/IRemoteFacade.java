package es.deusto.ingenieria.sd.auctions.server.remote;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Date;
import java.time.LocalTime;
import java.util.List;

import es.deusto.ingenieria.sd.auctions.server.data.dto.ChallengeDTO;
import es.deusto.ingenieria.sd.auctions.server.data.dto.TrainingSessionDTO;


	public interface IRemoteFacade extends Remote {	
	
		public long login(String account, String email, String password) throws RemoteException;
		
		public void logout(long token) throws RemoteException;
		
		public void register(String account, String email, String name, Date birthDate, float weight, float height, int mBPM, int bpm) throws RemoteException;
		
		public List<ChallengeDTO> getChallenges() throws RemoteException;
		
		public List<TrainingSessionDTO> getTrainingSessions(long token) throws RemoteException;
		
		public boolean acceptChallenge(long token, ChallengeDTO c) throws RemoteException;
		
		public boolean createSession(long token, String title, String sport, float Distance, Date startDate, LocalTime timeStart, float duration) throws RemoteException;
		
		public boolean setupDistanceChallenge(long token, String name, Date start, Date end, float metric, String sportType) throws RemoteException;
		
		public boolean setupActivityTimeChallenge(long token, String name, Date start, Date end, float metric, String sportType) throws RemoteException;

}